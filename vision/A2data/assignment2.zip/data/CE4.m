clear all

im1=imread('cube1.JPG');
im2=imread('cube2.JPG');
load('CE2.mat')
load('CE3.mat')

X=[];
for i = 1:max(size(x1))
    M=[P1 -[x1(:,i);1] [0 0 0]' ; P2 [0 0 0]' -[x2(:,i); 1]];
    [U,S,V]=svd(M);
    v=V(:,end);
    X=[X v(1:4,:)];
end
for i=1:max(size(X))
    X(:,i)=pflat(X(:,i));
end

xproj1=P1*X;
xproj2=P2*X;
for i=1:max(size(xproj1))
    xproj1(:,i)=pflat(xproj1(:,i));
    xproj2(:,i)=pflat(xproj2(:,i));
end

figure(1)
subplot(1,2,1)
imshow(im1);
hold on;
plot(xproj1(1,:), xproj1(2,:), 'xg', 'Markersize',5);
plot(x1(1,:),x1(2,:), 'xr', 'Markersize', 5)
hold off;
title('Image 1')
legend('Projected points','SIFT points')

subplot(1,2,2)
imshow(im2);
hold on;
plot(xproj2(1,:),xproj2(2,:), 'xg', 'Markersize',5);
plot(x2(1,:), x2(2,:), 'xr', 'Markersize', 5)
hold off;
title('Image 2')
legend('Projected points','SIFT points')

[K1,R1]=rq(P1);
[K2,R2]=rq(P2);

nx1=inv(K1)*[x1;ones(1,max(size(x1)))]; 
nx2=inv(K2)*[x2;ones(1,max(size(x2)))];
for i=1:max(size(nx1))
    nx1(:,i)=pflat(nx1(:,i));
    nx2(:,i)=pflat(nx2(:,i));
end
nx1=nx1(1:2,:);
nx2=nx2(1:2,:);
X=[];
for i=1:max(size(nx1))
    M=[P1 -[nx1(:,i);1] [0; 0; 0] ; P2 [0; 0; 0] -[nx2(:,i); 1]];
    [U,S,V]=svd(M);
    v=V(:,end);
    X=[X v(1:4,:)];
end
for i=1:max(size(X))
    X(:,i)=pflat(X(:,i));
end

xproj1 = K1*(P1*X);
xproj2 = K2*(P2*X);
for i=1:max(size(xproj1))
    xproj1(:,i)=pflat(xproj1(:,i));
    xproj2(:,i)=pflat(xproj2(:,i));
end

figure(2)
subplot(1,2,1)
imshow(im1);
hold on;
plot(xproj1(1,:), xproj1(2,:), 'xg', 'Markersize',5);
plot(x1(1,:), x1(2,:), 'xr', 'Markersize', 5)
hold off;
title('Image 1 with normalization')
legend('Projected points','SIFT points')

subplot(1,2,2)
imshow(im2);
hold on;
plot(xproj2(1,:), xproj2(2,:), 'xg', 'Markersize',5);
plot(x2(1,:), x2(2,:), 'xr', 'Markersize', 5)
hold off;
title('Image 2 with normalization')
legend('Projected points','SIFT points')